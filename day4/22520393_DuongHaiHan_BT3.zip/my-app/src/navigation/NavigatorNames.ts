export enum NavigatorNames {
    LOGIN = 'Login',
    EMPLOYEE_LIST = 'EmployeeList',
    EMPLOYEE_DETAIL = 'EmployeeDetail',
}